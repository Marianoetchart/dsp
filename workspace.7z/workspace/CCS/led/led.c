//LED.c LED with DIP switch control
void main()
{
 DSK6713_LED_init(); //initilize LED from BSL
 DSK6713_DIP_init(); //initilize DIP switch from BSL
 while(1) //infinite loop

 { //start of infinite loop
 if(DSK6713_DIP_get(0)==0) //=0 if DIP switch #0 pressed
 {
 DSK6713_waitusec(Uint32 de); 
 DSK6713_LED_on(0); //turn LED #0 ON
 }
 if(DSK6713_DIP_get(1)==0) //=0 if DIP switch #1 pressed
 {
 DSK6713_LED_on(1); //turn LED #0 ON
 }
 if(DSK6713_DIP_get(2)==0) //=0 if DIP switch #1 pressed
 {
 DSK6713_LED_on(2); //turn LED #0 ON
 }
 if(DSK6713_DIP_get(3)==0) //=0 if DIP switch #1 pressed
 {
 DSK6713_LED_on(3); //turn LED #0 ON
 }
 else{
 DSK6713_LED_off(0); //turn LED off if not pressed
 DSK6713_LED_off(1); //turn LED off if not pressed
 DSK6713_LED_off(2); //turn LED off if not pressed
 DSK6713_LED_off(3); //turn LED off if not pressed
 }
 } //end of while(1) infinite loop
}